To build project:
from build folder: 
cmake -G "Visual Studio 16 2019" ..
cmake --build . --config Release

from main directory (to execute imgDisplay
./build/Release/imgDisplay.exe

from main directory (to execute vidDisplay):
./build/Release/vidDisplay.exe

